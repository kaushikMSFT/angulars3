import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { UploaderComponent } from './uploader/uploader.component';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import {RouterModule} from '@angular/router';
//import { DxCheckBoxModule, DxFileUploaderModule, DxSelectBoxModule } from 'devextreme-angular';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

@NgModule({
  declarations: [
    AppComponent,
    UploaderComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
   
    RouterModule.forRoot( 
      [
        {path:'', component: UploaderComponent }
        

      ]
     )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }




platformBrowserDynamic().bootstrapModule(AppModule);
