
import { Component, OnInit } from '@angular/core';
import { UploaderService } from '../uploader.service';


@Component({
  selector: 'app-uploader',
  templateUrl: './uploader.component.html',
  styleUrls: ['./uploader.component.css']
})
export class UploaderComponent { 
  value: any[] = [];
  constructor(private uploaderService: UploaderService) {
    
    console.log('hello');
  }

 
 

    upload(files: File[]){
      //pick from one of the 4 styles of file uploads below
      //this.uploadAndProgress(files);
      var formData = new FormData();
      //const headers = new HttpHeaders().set('Content-Type', 'application/pdf; charset=utf-8');
      //Array.from(files).forEach(f => formData.append('file',f))
    

      /*this.uploaderService.Create1(files[0]).subscribe((response)=>{
            
      var strUrl= response['body'].replace(/["']/g, "").replace("https://","");;
      window.open( 'https://'+strUrl,'_blank');
       
      
      });*/
      //this.downloadFile(files);

      this.uploaderService.GeneratePreSigned(files[0], 'put').subscribe((response)=>{
            
      var strUrl= response['body'].replace(/["']/g, "").replace("https://","");;
      console.log('upload',strUrl);
      //window.open( 'https://'+strUrl,'_blank');
       this.uploaderService.Create2(files[0], strUrl).subscribe(response1=>
        {
          console.log(response1);
        });
      
    });

    
    
  }

  download(files: File[])
    {
        //this.uploaderService.Create1(files[0]).subscribe((response)=>{
          this.uploaderService.GeneratePreSigned(files[0], 'get').subscribe((response)=>{
            
      var strUrl= response['body'].replace(/["']/g, "").replace("https://","");;
      window.open( 'https://'+strUrl,'_blank');
       
      
      });
    }

}

