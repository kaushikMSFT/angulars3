import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Binary } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class UploaderService {

  constructor(private httpService: HttpClient) {
     //formData = auditPortfolio;
    
  }

    GeneratePreSigned(file : File, httpVerb : string) //this is to generate the presignedurl
  {
    const headers = new HttpHeaders({
      'Content-Type': 'application/pdf'
    });
    console.log(file)
    //return this.httpService.post(" https://ujpwdxg8hi.execute-api.ap-south-1.amazonaws.com/v2", "",{headers});
    //return this.httpService.post("https://p885qx6aoa.execute-api.ap-south-1.amazonaws.com/Stagedev","",{headers});
    //return this.httpService.post("https://vhfb4w51xd.execute-api.ap-south-1.amazonaws.com/v1/upload",file, {headers});
    //return this.httpService.get("https://2ksrucazd9.execute-api.ap-south-1.amazonaws.com/v1/upload-api-bucket1?file=0.pdf");
    //using proxylambda -- did not work
    //return this.httpService.get("https://0bpjc8onm4.execute-api.ap-south-1.amazonaws.com/v1/upload-api-bucket1?file=0.pdf",{ responseType: 'blob'});
     //above worked
     //presigned
     //return this.httpService.get("https://cts1ecns05.execute-api.ap-south-1.amazonaws.com/v1/upload-api-bucket1?file=0.pdf");
     //above did not work bcos of region. it was expecting us-east1
     if(httpVerb =='get')
     //below is for get
        return this.httpService.get("https://ywtpn45p4j.execute-api.us-east-1.amazonaws.com/v1/upload-api-bucket1?file=50.pdf");
     if(httpVerb == 'put')
     //below is for put
        return this.httpService.get("https://1ex6y67rfe.execute-api.us-east-1.amazonaws.com/v1/upload-api-bucket1?file=50.pdf")
     // above is working now. Previously it was giving signature problem . now i have added signatureversion in  lamdba
      // .pipe(catchError(this.handleError));
   }

   Create2(file : File, url : string)
   {
    const headers = new HttpHeaders({
    //'Content-Type': 'binary/octet-stream',
       'x-amz-acl': 'public-read'
    });
      return this.httpService.put('https://'+url,file);
   }
}
